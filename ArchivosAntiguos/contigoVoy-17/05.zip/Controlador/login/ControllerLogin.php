<?php 
    if (isset($_POST["usu"]) && isset($_POST["pass"])) {
        require("/home3/ghxumdmy/public_html/gestion-contigo-voy-com/Modelo/login/ModelLogin.php");
        $validar = new Login();
        $validar->validarDatos($_POST["usu"], $_POST["pass"]);
    } else {
        header("location:../index.php");
    }
?>